* WinPcap Developer's pack    *
* Release 2.3 - March 2002    *
* Written by Loris Degioanni  * 


This archive contains all the stuff useful to create new network capture applications using winpcap. 
The archive contains the following folders:

- drivers               Binaries of WinPcap's drivers and DLLs for Win95/98/ME, 
                        WinNT4 and Win2K. Useful to test the programs.
- examples              Sample applications showing various uses of of winpcap 
                        and packet.dll.
- lib		        library files needed to create capture applications
- include		include files needed to create capture applications

see the documentation at http://netgroup-serv.polito.it/winpcap for manuals, instructions and details.
