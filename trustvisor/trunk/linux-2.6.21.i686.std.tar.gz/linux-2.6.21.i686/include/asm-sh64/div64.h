#ifndef __ASM_SH64_DIV64_H
#define __ASM_SH64_DIV64_H

#include <asm-generic/div64.h>

#endif /* __ASM_SH64_DIV64_H */
