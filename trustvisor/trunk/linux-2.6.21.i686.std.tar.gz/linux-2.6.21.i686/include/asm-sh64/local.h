#ifndef __ASM_SH64_LOCAL_H
#define __ASM_SH64_LOCAL_H

#include <asm-generic/local.h>

#endif /* __ASM_SH64_LOCAL_H */

