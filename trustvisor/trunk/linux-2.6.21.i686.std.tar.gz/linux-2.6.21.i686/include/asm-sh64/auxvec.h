#ifndef __ASM_SH64_AUXVEC_H
#define __ASM_SH64_AUXVEC_H

#endif /* __ASM_SH64_AUXVEC_H */
