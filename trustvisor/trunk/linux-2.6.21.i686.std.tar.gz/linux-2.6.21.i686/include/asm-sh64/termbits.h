#ifndef __ASM_SH64_TERMBITS_H
#define __ASM_SH64_TERMBITS_H

#include <asm-sh/termbits.h>

#endif /* __ASM_SH64_TERMBITS_H */
