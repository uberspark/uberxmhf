#ifndef __ASM_SH64_LINKAGE_H
#define __ASM_SH64_LINKAGE_H

#include <asm-sh/linkage.h>

#endif /* __ASM_SH64_LINKAGE_H */

