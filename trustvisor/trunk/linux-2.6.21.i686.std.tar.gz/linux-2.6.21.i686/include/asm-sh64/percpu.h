#ifndef __ASM_SH64_PERCPU
#define __ASM_SH64_PERCPU

#include <asm-generic/percpu.h>

#endif /* __ASM_SH64_PERCPU */
