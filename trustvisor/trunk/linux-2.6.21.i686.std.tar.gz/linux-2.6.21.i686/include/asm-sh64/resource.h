#ifndef __ASM_SH64_RESOURCE_H
#define __ASM_SH64_RESOURCE_H

#include <asm-sh/resource.h>

#endif /* __ASM_SH64_RESOURCE_H */
