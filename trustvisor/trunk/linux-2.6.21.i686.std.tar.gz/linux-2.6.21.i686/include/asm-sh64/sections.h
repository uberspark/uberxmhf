#ifndef __ASM_SH64_SECTIONS_H
#define __ASM_SH64_SECTIONS_H

#include <asm-sh/sections.h>

#endif /* __ASM_SH64_SECTIONS_H */

