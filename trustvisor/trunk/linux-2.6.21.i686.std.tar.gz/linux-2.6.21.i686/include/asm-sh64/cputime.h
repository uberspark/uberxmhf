#ifndef __SH64_CPUTIME_H
#define __SH64_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __SH64_CPUTIME_H */
