#ifndef __ASM_SH64_KMAP_TYPES_H
#define __ASM_SH64_KMAP_TYPES_H

#include <asm-sh/kmap_types.h>

#endif /* __ASM_SH64_KMAP_TYPES_H */

