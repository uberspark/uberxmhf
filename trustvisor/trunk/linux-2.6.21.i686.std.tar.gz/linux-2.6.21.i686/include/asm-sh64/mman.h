#ifndef __ASM_SH64_MMAN_H
#define __ASM_SH64_MMAN_H

#include <asm-sh/mman.h>

#endif /* __ASM_SH64_MMAN_H */
