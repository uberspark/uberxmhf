#ifndef __ASM_SH64_ERRNO_H
#define __ASM_SH64_ERRNO_H

#include <asm-generic/errno.h>

#endif /* __ASM_SH64_ERRNO_H */
