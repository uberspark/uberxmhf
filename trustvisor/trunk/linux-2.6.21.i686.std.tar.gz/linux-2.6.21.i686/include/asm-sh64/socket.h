#ifndef __ASM_SH64_SOCKET_H
#define __ASM_SH64_SOCKET_H

#include <asm-sh/socket.h>

#endif /* __ASM_SH64_SOCKET_H */
