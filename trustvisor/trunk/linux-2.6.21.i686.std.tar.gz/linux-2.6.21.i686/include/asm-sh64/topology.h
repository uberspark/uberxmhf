#ifndef __ASM_SH64_TOPOLOGY_H
#define __ASM_SH64_TOPOLOGY_H

#include <asm-generic/topology.h>

#endif /* __ASM_SH64_TOPOLOGY_H */
