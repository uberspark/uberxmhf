/*
 * linux/include/asm-sh64/mc146818rtc.h
 *
*/

/* For now, an empty place-holder to get IDE to compile. */

