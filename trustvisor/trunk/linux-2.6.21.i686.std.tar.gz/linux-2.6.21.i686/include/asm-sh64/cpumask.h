#ifndef __ASM_SH64_CPUMASK_H
#define __ASM_SH64_CPUMASK_H

#include <asm-generic/cpumask.h>

#endif /* __ASM_SH64_CPUMASK_H */
