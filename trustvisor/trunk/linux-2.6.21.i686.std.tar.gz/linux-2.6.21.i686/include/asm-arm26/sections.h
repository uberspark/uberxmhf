//FIXME - nicked from arm32 - check its correct.
#include <asm-generic/sections.h>
