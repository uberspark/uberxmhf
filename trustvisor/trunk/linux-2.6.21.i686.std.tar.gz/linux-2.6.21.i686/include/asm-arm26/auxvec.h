#ifndef __ASMARM_AUXVEC_H
#define __ASMARM_AUXVEC_H

#endif
