#ifndef __ARM26_CPUTIME_H
#define __ARM26_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __ARM26_CPUTIME_H */
