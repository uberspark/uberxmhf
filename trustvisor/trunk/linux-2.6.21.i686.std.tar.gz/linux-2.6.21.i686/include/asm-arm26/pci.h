/* Should not be needed. IDE stupidity */
/* JMA 18.05.03 - is kinda needed, if only to tell it we don't have a PCI bus */

#define PCI_DMA_BUS_IS_PHYS  		0
#define pcibios_scan_all_fns(a, b)	0

