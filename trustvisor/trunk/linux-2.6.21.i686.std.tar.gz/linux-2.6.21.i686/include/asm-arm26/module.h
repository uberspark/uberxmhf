#ifndef _ASM_ARM_MODULE_H
#define _ASM_ARM_MODULE_H
/*
 * This file contains the arm architecture specific module code.
 */

#endif /* _ASM_ARM_MODULE_H */
