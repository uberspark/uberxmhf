#ifndef _ASMARM_STATFS_H
#define _ASMARM_STATFS_H

//FIXME - this may not be appropriate for arm26. check it out.

#include <asm-generic/statfs.h>

#endif
