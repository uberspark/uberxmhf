#ifndef _ARM_ERRNO_H
#define _ARM_ERRNO_H

#include <asm-generic/errno.h>

#endif
