#ifndef __ASM_LINKAGE_H
#define __ASM_LINKAGE_H

/* Nothing to see here... */

#endif
